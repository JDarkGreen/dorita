=== Duplicate Page ===
Contributors: mndpsingh287

Donate link: http://www.webdesi9.com/donate/?plugin=duplicate-page
Tags: Page Duplicate, Post duplicate, duplicate custom posts, duplicate page, duplicate post, duplicate ,custom posts, post, page, duplicate this, duplicate, content duplicate, duplicate content, data duplicate, duplicate data, copy page, clone page,wordpress page duplicate, wordpress post duplicate, Copy post, wordpress page duplicator, wordpress post duplicator, Cloner
Requires at least: 3.4
Tested up to: 4.5
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Duplicate Posts, Pages and Custom Posts easily using single click

== Description ==

Duplicate Posts, Pages and Custom Posts easily using single click. You can duplicate your pages, posts and custom post by just one click and it will save as your selected options (draft, private, public, pending).


== Installation ==

1. Upload the `duplicatepage` folder to the directory `/wp-content/plugins/`.
2. Activate the plugin using the 'Plugins' menu in WordPress.

== Frequently asked questions ==

## How to use

1. First Activate Plugin.
2. Go Select to Duplicate Page settings Menu from Settings Tab and savings settings . 
1. Then Create New Post/Page Or Use old.
2. After click on duplicate this link, then duplicate post/ page will be created and saved as draft,publish,pending,private depending upon settings.

== Screenshots ==

1. Activate Screen 
2. Duplicate Page Settings Screen
3. Select Option from Settings Page.
4. Click on Duplicate This. 
5. Duplicate Post / Page will Appear. 

== Changelog ==

= 1.1 (04th May ,2016) =

* fix some Bug in 1.0

= 1.2 (05th May, 2016) =

* Duplicate Page Settings Menu Added.

= 1.3 (23th May, 2016) =

* New Features added



== Other Notes ==

= Minimum requirements for Duplicate Page =
*   Wordpress 3.3+
*   PHP 5.x
*   MySQL 5.x

If any problem occurs, please contact us at [mandeep.singh@mysenseinc.com](mailto:mandeep.singh@mysenseinc.com).







