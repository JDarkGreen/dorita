<div id="linkforms"  class="tab hidden tab-table">
    
    <div class="outer_wrap_single">
        <div class="outer_wrap"> 
    
    
                <h3>Links</h3>
                <div class="postbox">
    <div class="inside">
    <table class="form-table">	
                    <tbody>
                        <tr>
                            <th>Colour</th>
                            <td>
                                <input type="text" placeholder="Pick A Colour" name="colors[link]" data-color="yes" value="<?php echo $this->scss_val('link'); ?>" class="lacc_colorpicker">
                            </td>
                        </tr>
                        <tr>
                            <th>Focus Colour</th>
                            <td>
                                <input type="text" placeholder="Pick A Colour" name="colors[link-focus]" data-color="yes" value="<?php echo $this->scss_val('link-focus'); ?>" class="lacc_colorpicker">
                            </td>
                        </tr>
                    </tbody>
                </table>
                    </div></div></div>
        
        <div class="outer_wrap">
 
            
                <h3>Forms</h3>
                <div class="postbox">
    <div class="inside">
    <table class="form-table">	
                    <tbody>
                        <tr>
                            <th>Form Checked</th>
                            <td>
                                <input type="text" placeholder="Pick A Colour" name="colors[form-checked]" data-color="yes" value="<?php echo $this->scss_val('form-checked'); ?>" class="lacc_colorpicker">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
                    
    </div>
        </div></div>
</div>