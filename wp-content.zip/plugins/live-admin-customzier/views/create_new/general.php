<div id="general"  class="tab active tab-table">
	<div class="table_rows">
		
        <div class="postbox">
            <div class="inside">
                <table class="form-table">
                    <tbody>
                        <tr>
                            <th>Base Colour</th>
                            <td>
                                <input type="text" placeholder="Pick A Colour" 
                                       name="colors[base-color]" data-color="yes" value="<?php echo $this->scss_val('base-color'); ?>" class="lacc_colorpicker">
                            </td>
                        </tr>

                        <tr>
                            <th>Body Background</th>
                            <td>
                                <input type="text" placeholder="Pick A Colour" 
                                       name="colors[body-background]" data-color="yes" value="<?php echo $this->scss_val('body-background'); ?>" class="lacc_colorpicker">
                            </td>
                        </tr>
                        <tr>
                            <th>Button Colour</th>
                            <td>
                                <input type="text" placeholder="Pick A Colour" 
                                       name="colors[button-color]" data-color="yes" value="<?php echo $this->scss_val('button-color'); ?>" class="lacc_colorpicker">
                            </td>
                        </tr>
                    </tbody>
                </table>
        
                <table class="form-table">
                    <tbody>
                        <tr>
                            <th>Action Button Colour</th>
                            <td>
                                <input type="text" placeholder="Pick A Colour" 
                                       name="colors[button-color]" data-color="yes" value="<?php echo $this->scss_val('button-color'); ?>" class="lacc_colorpicker">
                            </td>
                        </tr>
                        <tr>
                            <th>Secondary Button Colour</th>
                            <td>
                                <input type="text" placeholder="Pick A Colour" 
                                       name="colors[secondary-button-color]" data-color="yes" value="<?php echo $this->scss_val('secondary-button-color'); ?>" class="lacc_colorpicker">
                            </td>
                        </tr>

                    </tbody>
                </table> 
            </div>
        </div>        
	</div>

</div>