<div class='success updated'>
	<p><?php _e('Saved successfully', 'wpmf'); ?></p>
</div>
