var j = jQuery.noConflict();

(function($){

	//Agregar Color picker a este input con esta clase
	j('.js-add-theme-color').wpColorPicker();
  
})(jQuery);